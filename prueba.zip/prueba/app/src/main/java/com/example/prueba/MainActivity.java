package com.example.prueba;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {
        TextInputEditText nombre,apellido,edad;
        TextView res;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //inicializar
        nombre=findViewById(R.id.txtnombre);
        apellido=findViewById(R.id.txtapellido);
        res=findViewById(R.id.txtresultado);
        edad = findViewById(R.id.txtedad);


    }

    public void imprimir(View view) {
        String nombreCompleto=nombre.getText().toString()+" "+apellido.getText().toString();
        int edadentera=Integer.parseInt(edad.getText().toString());
        res.setText("El nombre completo es:"+nombreCompleto.toUpperCase()+ " Y tiene "+edadentera+ " años");
    }
}
